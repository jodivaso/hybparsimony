hybparsimony package
====================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   hybparsimony.lhs
   hybparsimony.util

Submodules
----------

hybparsimony.Examples module
----------------------------

.. automodule:: hybparsimony.Examples
   :members:
   :undoc-members:
   :show-inheritance:

hybparsimony.hybparsimony module
--------------------------------

.. automodule:: hybparsimony.hybparsimony
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: hybparsimony
   :members:
   :undoc-members:
   :show-inheritance:
