hybparsimony.lhs package
========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   hybparsimony.lhs.base
   hybparsimony.lhs.util

Module contents
---------------

.. automodule:: hybparsimony.lhs
   :members:
   :undoc-members:
   :show-inheritance:
